package pt.ua.gboard.games;

public enum Suits {SPADES, HEARTS, DIAMONDS, CLUBS};

