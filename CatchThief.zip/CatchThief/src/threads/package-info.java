/**
 * This package contains all the active entities.
 */
package threads;
