/**
 * This package contains the GPS, the GPSMonitor is responsible for the coordinates to go from x to y.
 */
package gps;
