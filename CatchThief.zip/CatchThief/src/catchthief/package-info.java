/**
 * This package contains the Main class and the CityMap.
 */
package catchthief;
