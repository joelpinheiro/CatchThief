/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catchthief;

import informationCentral.InformationCentralMonitor;
import java.awt.Color;
import java.awt.Point;
import static java.lang.System.err;
import static java.lang.System.exit;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import threads.Passerby;
import pt.ua.gboard.Gelem;
import pt.ua.gboard.StringGelem;
import pt.ua.gboard.games.PacmanGelem;
import threads.Cop;
import threads.Thief;

/**
 *
 * @author joelpinheiro
 */
public class Main {
    
    /**
     * @param args the command line arguments
     */
    public static int NUMBER_OF_COPS = 2;
    public static int NUMBER_OF_PASSERBIES = 2;
    public static int NUMBER_OF_THIEFS = 2;
    
    static void help() {
        System.out.println("Incorrect parameters number.");
        System.out.println("Usage: java -ea catchthief.Main [NUMBER_OF_COPS] [NUMBER_OF_PASSERBIES]  [NUMBER_OF_THIEFS]  [MAP_FILE]  "
                + "[PRISON_SYMBOL]  [HIDINGPLACE_SYMBOL]    [PASSERBY_SYMBOL]   [OBJECT_TO_STEAL_SYMBOL]\n");
        System.out.println("EXAMPLE:");
        System.out.println("java -ea catchthief.Main 1 1 1 ./board/labyrinth.txt 100 P H T $");
    }
    
    public static void main(String[] args) {

        if(args.length != 8){
            help();
            System.exit(0);
        }
        
        System.out.println("\nSimulation output:");
            
        NUMBER_OF_COPS = Integer.parseInt(args[0]);
        NUMBER_OF_PASSERBIES = Integer.parseInt(args[1]);
        NUMBER_OF_THIEFS = Integer.parseInt(args[2]);
        
        String mapa = args[3];
        
        int pause = 100;                 // waiting time in each step [ms]
        char prisonSymbol =  args[4].charAt(0);                 // prisonSymbol
        char hindingPlaceSymbol = args[5].charAt(0); 
        char passerbyHouseSymbol = args[6].charAt(0);
        char objectToStealSymbol = args[7].charAt(0);
        char actualPositionSymbol = '•';
        
        char[] extraSymbols
                = {
                    prisonSymbol,
                    hindingPlaceSymbol,
                    passerbyHouseSymbol,
                    objectToStealSymbol,
                    actualPositionSymbol
                };
        
        Gelem[] gelems = {
            new StringGelem("" + prisonSymbol, Color.blue),
            new StringGelem("" + hindingPlaceSymbol, Color.red),
            new StringGelem("" + passerbyHouseSymbol, Color.gray),
            new StringGelem("" + objectToStealSymbol, Color.RED),
            new StringGelem("" + actualPositionSymbol, Color.green),
            new PacmanGelem(Color.green, 40),
            new PacmanGelem(Color.green, 60)
        };
        
        CityMap cityMap = new CityMap(pause, mapa, extraSymbols, gelems);
        InformationCentralMonitor informationCentralMonitor = new InformationCentralMonitor();

        
        Point[] PasserbyHousePositions = CityMap.getMaze().roadSymbolPositions(passerbyHouseSymbol);
        if (PasserbyHousePositions.length != 1) {
            err.println("ERROR: one, and only one, start point required!");
            exit(2);
        }
        
        Point[] PrisonPositions = cityMap.getMaze().roadSymbolPositions(prisonSymbol);
        if (PrisonPositions.length != 1) {
            err.println("ERROR: one, and only one, start point required!");
            exit(2);
        }
        
        Point[] thiefHidingPlacePositions = cityMap.getMaze().roadSymbolPositions(hindingPlaceSymbol);
        if (thiefHidingPlacePositions.length != 1) {
            err.println("ERROR: one hiding place, and only one, start point required!");
            exit(2);
        }

        Color passerbyColor = Color.green;
        for(int i = 0 ; i < NUMBER_OF_PASSERBIES ; i++) {
            Map markedPositionsPasserBy = new TreeMap<>();
            Passerby passerby = new Passerby(informationCentralMonitor, PasserbyHousePositions, markedPositionsPasserBy, extraSymbols, passerbyColor);
            passerby.start();
            
            // pt.ua.concurrent.
            // java.util.concurrent.Executors.scheduleAtFixedRate(Runnable n, long initialDelay, long period, TimeUnit unit);

            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        for(int i = 0 ; i < NUMBER_OF_THIEFS ; i++) {
            Map markedPositionsThief = new TreeMap<>();
            Color thiefColor = Color.red;
            Thief thief = new Thief(informationCentralMonitor, thiefHidingPlacePositions, markedPositionsThief, extraSymbols, thiefColor);

            thief.start();
            
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        for(int i = 0 ; i < NUMBER_OF_COPS ; i++) {
            Color copColor = Color.blue;
            Map markedPositionsCop = new TreeMap<>();
            Cop cop = new Cop(informationCentralMonitor, PrisonPositions, markedPositionsCop, extraSymbols, copColor);
            cop.start();
            
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
 
}
