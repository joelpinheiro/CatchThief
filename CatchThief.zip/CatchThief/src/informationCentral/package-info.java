/**
 * This package contains the informationCentralMonitor, it gives the position of the most important active entities.
 */
package informationCentral;
