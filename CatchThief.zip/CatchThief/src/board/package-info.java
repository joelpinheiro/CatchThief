/**
 * This package contains the Board of the simulation, it is a singleton to all the active entities.
 */
package board;
